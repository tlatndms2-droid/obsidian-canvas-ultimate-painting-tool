# Canvas Drawing Tool Bar — Final Development Plan

## 1. 제품 한 줄 정의

Obsidian Desktop Canvas 자체를 그림판으로 확장하여, Card/Image/Group 등 기존 Canvas Item과 Drawing을 같은 공간에서 사용하면서 CSP에 가까운 Drawing 경험을 제공하는 개인용 Windows Desktop Plugin.

## 2. 최상위 제품 원칙

1. Obsidian Canvas 자체가 Drawing Surface다.
2. 별도의 Drawing Canvas / Drawing Area를 만들지 않는다.
3. Clip Studio Paint에 가까운 Drawing UX를 목표로 한다.
4. Drawing 때문에 기존 Obsidian Canvas의 성능과 사용성을 희생하지 않는다.
5. 성능은 P0다.
6. 데이터 손실 방지는 기능 추가보다 우선한다.
7. 기존 Canvas 조작을 불필요하게 훼손하지 않는다.
8. 기술 구현 방법은 Codex가 검증한다. 기획은 사용자 결과와 완료 조건을 규정한다.

## 3. Mode

### Selection
기존 Obsidian Canvas 조작 모드.
Card / Image / Group / Text Box 등 Canvas Item을 선택, 이동, Resize, 편집한다.

### Drawing
Drawing Toolbar와 Layer Panel을 사용하는 Drawing 작업 모드.
Brush / Eraser / Shape / Drawing Selection 등을 사용한다.

Drawing Mode 진입:
- Drawing Toolbar 자동 오픈
- Layer Panel 자동 오픈
- 마지막 Tool/Sub Tool/Workspace 환경 복원

Drawing Mode 종료:
- Drawing Toolbar와 Layer Panel 닫힘
- Selection Mode의 기존 Canvas 조작 복귀

Toolbar/Context Panel/Layer Panel은 Drawing Mode를 유지한 채 접고 펼칠 수 있다.

## 4. 입력 공통

- Space + 좌클릭 Drag = Pan
- Middle Drag = Pan
- Wheel = Zoom
- Tool이 Wheel을 일시 소비하는 상태에서는 Zoom 차단
- Ctrl+Alt+좌우 Drag = Brush/Eraser Size 연속 조절
- Ctrl+Z / Ctrl+Shift+Z = 현재 작업 대상의 Undo/Redo

## 5. History 원칙

사용자는 History 종류를 직접 고르지 않는다.

- Brush/Eraser/Shape/Drawing Selection/Layer 작업 = Drawing History
- Card/Image/Group/Text Box 등 Canvas Item 작업 = Canvas History
- 현재 작업 대상에 맞춰 Ctrl+Z가 자동 적용
- 복합 작업 Undo = 작업 직전 상태 전체 복원
- Merge Undo = Layer 구조 + Drawing + Anchor 관계 복원
- Anchor Target 변경 Undo = 이전 Target/상태 복원

## 6. Rendering / Z-order

- 모든 Drawing Layer는 기존 Canvas Item보다 항상 위에 표시
- Drawing Layer끼리의 Z-order는 Layer Panel 순서
- Canvas Item 뒤로 Drawing을 보내는 기능은 제공하지 않음
- Anchor는 Z-order에 영향을 주지 않음

## 7. 개발 진행 원칙

개발은 Gate 단위로 진행한다.

`Canvas/저장 기반 → Drawing Engine → Brush·Pen → Layer → Selection/Transform → Anchored Drawing → Shape/Text → Workspace/Asset → 통합 → Performance/Data Safety → v1`

각 Gate:
1. Codex 구현
2. Codex 자체 검증
3. 독립 Obsidian Sandbox 검증
4. Sandbox를 닫지 않고 검증 상태 그대로 유지
5. 사용자가 직접 확인
6. 실패 시 동일 Gate 수정/재검증
7. 통과 시 증거 보존
8. GitHub Patch Release
9. 다음 Gate

Gate 미통과 상태에서는 다음 Gate로 넘어가지 않는다.

# HANDOFF TO CODEX

## 목적

이 문서는 구현 코드를 지시하는 문서가 아니라,
Codex가 기능별 개발 계획과 Gate 실행을 바로 시작할 수 있게 하는 최종 제품 요구사항 Handoff다.

## Source 우선순위

1. 이 Final Planning Pack
2. 최신 사용자 결정
3. Source Archive

Source Archive와 충돌하면 Final Pack을 따른다.

## 폐기된 과거 기획

아래는 구현하면 안 된다.

- 별도 Drawing Canvas / Drawing Area
- Stroke 1개 = Canvas Node 1개
- Card Drawing Mode
- 선택한 Card 안에서만 Drawing
- Card 전용 별도 Layer Stack
- Anchor가 Resize/Scale 따라가기
- Target 삭제 시 Drawing 삭제
- Target 개별 복제 시 Anchored Drawing 자동 복제
- Shape를 영구 Vector Shape 객체로 유지
- Text Layer
- Text를 Drawing Layer에 저장
- Text Anchor
- Text를 Drawing Visibility/Filter에 포함
- Color 독립 Tool
- Toolbar 사용자 구분선
- Dual Brush
- Barrel Rotation
- Layer Duplicate 제외
- Plugin 자체 작품 Backup

## 최신 추가/변경

- Layer Duplicate v1 포함
- Group Duplicate v1 포함
- Text = Canvas Item
- Color = Shortcut Popup + Auto-close + Pin
- Tool Toolbar 순서 변경/숨김 Workspace 저장
- Drawing Selection 명칭 사용
- Workspace = 작업환경 전환 단위
- Gate마다 Sandbox 사용자 직접 확인
- Gate 통과 시 GitHub Patch Release
- 모든 v1 Gate 통과 후 1.0.0

## 개발 시작 전

Codex는 각 Gate 시작 전에:
1. 해당 Gate Acceptance Criteria를 명시
2. 기술 검증 항목을 명시
3. 기존 Gate 결과를 깨지 않는 Regression Test 항목 작성
4. Sandbox 준비
5. 실제 검증 가능 상태까지 구현

## Gate 종료

Gate 구현 완료만으로 종료하지 않는다.

종료 조건:
- Codex 검증 Pass
- Sandbox Pass
- Sandbox 상태 유지
- 사용자 직접 확인 Pass
- 증거 보존
- GitHub Release 생성

그 이후 다음 Gate로 이동.

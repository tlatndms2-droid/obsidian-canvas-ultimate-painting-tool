# Latest Decision Overrides

과거 Source와 충돌할 경우 아래가 최신 결정이다.

## Text
과거: 현재 Drawing Layer에 생성 / Text Layer 가능성
최신: Canvas 내부 독립 Item. Layer Panel/Anchor/Drawing Visibility와 무관.

## Shape
과거: 생성 후 영구 편집 객체
최신: 생성 직후만 임시 편집, 이후 일반 Drawing.

## Layer Duplicate
과거: 제외
최신: v1 포함. Group Duplicate도 포함.

## Color
과거: Toolbar의 Color Tool
최신: 독립 Tool 아님. Shortcut Color Popup.

## Anchor
과거 일부: Card 전용 / Resize 연동 / Target 삭제 시 Drawing 삭제
최신: Canvas Item 이동만 추적. Resize 미연동. Target 삭제 시 Drawing 보존.

## Canvas 전체 복제
최신: Drawing/Layer/Canvas Item 독립 복제 + 복제본끼리 Anchor 유지.

## Target 단독 복제
최신: Anchored Drawing 미복제.

## Workspace
최신: 단순 Backup 파일 개념이 아니라 **Drawing 작업환경 전환 단위**.

## Release
최신: Gate Pass 후 Patch Release. 기존 Release 덮어쓰기 금지.

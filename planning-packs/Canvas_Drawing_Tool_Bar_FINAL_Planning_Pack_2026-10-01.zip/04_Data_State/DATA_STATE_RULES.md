# Data / State / Lifecycle Rules

## Drawing Data

대량 Drawing Data는 `.canvas` 내부에 누적하지 않는 별도 Drawing Data로 관리하는 방향.
정확한 포맷/경로/직렬화는 Codex 기술 검증.

Drawing Data:
- Drawing Layer
- Group
- Brush/Eraser/Shape 결과
- Layer 설정
- Anchor 관계
- Canvas별 Drawing Visibility 상태 등

Text Box:
- Canvas Item
- Drawing Data의 Layer 시스템에 속하지 않음

## Auto-save

`Drawing Input → Memory 즉시 반영 → 변경 누적 → Batch Auto-save`

금지:
- Pointer Move마다 디스크 저장

필요 시:
- Canvas 전환/닫기
- Obsidian 종료
남은 변경사항 보존

## Data Safety

손상/미지원 데이터:
- 자동 초기화 금지
- 자동 덮어쓰기 금지
- 원본 보존
- 정상 데이터 영향 없음

구버전이 이해하지 못하는 최신 데이터:
- 임의 저장/변환 금지
- 원본 보호

동일 원칙:
- Drawing
- Workspace
- Brush Preset
- Custom Tip
- Texture
- 기타 Plugin 데이터

## Canvas Rename / Move

Obsidian 내부 이름 변경/폴더 이동:
- Drawing 연결 유지

Windows 파일 탐색기에서 같은 Vault 내부 Rename/Move:
- Drawing 연결 유지 요구

다른 Vault에 `.canvas` 파일만 단독 복사:
- Drawing 자동 이전 보장 안 함

## Canvas Duplicate

Canvas 전체 복제:
- Canvas Item 독립 복제
- Drawing 독립 복제
- Layer/Group 독립 복제
- 복제된 Target과 복제된 Drawing의 Anchor 관계 유지
- 원본과 이후 완전 독립

## Delete / Restore

복원 가능한 삭제:
- Obsidian `.trash`
- Windows 휴지통

복원 시 Drawing도 복원되어야 함.

영구 삭제:
- 영구 삭제를 안전하게 판정할 수 있을 때만 고아 Drawing Data 자동 정리
- 불확실하면 삭제하지 않음

## Plugin Disable / Reinstall

Plugin 비활성/제거:
- Drawing Data 삭제 금지

재활성/재설치:
- 기존 Drawing 복원

## Multiple Canvas

여러 Canvas 동시 오픈:
- 작품 상태는 Canvas별 독립
- Drawing Workspace/Brush Tool 환경은 공통

Canvas A 저장 중 B로 전환/작업:
- 데이터 섞임 금지
- Canvas별 저장 격리 필수

## Anchor Lifecycle

Target 삭제:
- Drawing 보존
- Anchor 해제

Target 삭제 Undo:
- Target + Anchor 관계 복원

Target 다른 Canvas 이동:
- Anchor 해제
- Drawing은 원래 Canvas에 유지

Target 미확인:
- Anchor 정보 유지
- 재연결 시도

## Workspace Lifecycle

Workspace = 전환 가능한 Drawing 작업환경.

전환:
- 현재 Workspace 환경 자동 저장
- 선택 Workspace 환경 활성
- 작품 데이터 변경 없음

Import:
- 자동 활성화 안 함
- 동일 이름은 별도 Workspace
- 일부 손상 항목은 제외하고 정상 항목 Import
- 동일 Asset을 확실히 판정 가능하면 기존 Asset 재사용

Workspace 삭제:
- 확인
- 해당 Workspace 환경/전용 Asset 삭제
- Canvas Drawing 영향 없음

## Full Settings Backup

대상:
- 모든 Workspace
- Brush/Tip/Texture Asset
- Plugin Settings

비대상:
- Canvas 작품 Drawing Data

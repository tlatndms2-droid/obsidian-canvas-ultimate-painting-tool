# Product Requirements

## Drawing Toolbar

왼쪽 세로 Toolbar.

최상위 고정:
- Selection / Drawing Mode 전환
- 하단 Drawing Workspace 선택기

Drawing Tool 영역:
- Tool 순서 Drag & Drop 변경 가능
- Tool 표시/숨김 가능
- 순서/표시 상태는 Workspace별 저장
- Toolbar 구분선 기능 없음

주요 Tool:
- Brush
- Eraser
- Drawing Selection
- Shape
- Text
- Eyedropper

Color는 독립 Tool이 아니다.

## Tool Context Panel

Toolbar 오른쪽의 동일 위치 Context Panel.
선택 Tool에 따라 내용 교체.
접힘/펼침 상태와 폭은 Workspace에 저장.
모든 Tool이 반드시 Panel을 가질 필요는 없음.

## Tool / Sub Tool / Preset

지원:
- 복제
- 사용자 생성
- 이름 변경
- 삭제
- Group 정리
- 설정 저장
- Pin
- Shortcut

Pin:
- 별도 Quick Access Bar 없음
- 현재 Tool Context Panel 상단 Pinned 영역
- 원래 목록에도 계속 존재

Default Preset:
- CSP 참고의 비교적 풍부한 기본 세트
- 직접 수정/삭제 가능
- 개별 Default 복원
- 전체 Default Preset 복원

## Shortcut

Brush Preset:
- 우클릭 → Shortcut 설정
- 단일 키, Ctrl/Shift/Alt 조합
- Drawing Mode에서만 작동
- 중복 할당 시 자동 덮어쓰기 금지
- 사용자 확인 후 이전 Shortcut을 새 Preset으로 이동

Color Mixing Toggle:
- 사용자 지정 Shortcut
- Drawing Mode에서만
- Toggle 방식
- Preset별 ON/OFF 저장

## Brush Engine

핵심 설정 영역:
1. Brush Size
2. Ink
3. Color Mixing
4. Brush Tip
5. Stroke
6. Stabilization
7. Texture
8. Spray / Scatter
9. Dynamics

### Brush Size
- Slider
- Number input
- Ctrl+Alt+좌우 Drag
- Minimum Size
- Pressure Curve
- Size Pressure ON/OFF + 영향 강도
- Opacity Pressure ON/OFF + 영향 강도

### Cursor
Brush/Eraser 사용 중 항상 표시.
가능하면 실제 Tip 형태/크기/Angle/Roundness 반영.
표시 모드:
- Tip + Hotspot 기본
- Tip only
- Hotspot only

배경 밝기에 따라 자동 대비.
수동 Cursor Color 설정 없음.

### Stabilization
Preset별 저장.
Panel에서 조절.
별도 Toggle Shortcut 없음.
Post-correction 별도 기능 없음.

### Brush Tip
Dual Brush / Layered Brush Tips 없음.
Brush 하나당 Tip 하나.

Circle Tip:
- Size
- Hardness
- Roundness/Thickness
- Angle
- Hardness는 Pressure 연동하지 않는 Preset 값

Custom Tip:
- 사용자 이미지 Import
- Tip Library 등록/재사용
- 원본 이미지 편집기 없음
- Scale / Angle / Flip 등 Brush 속성

Spacing:
- Preset에서 직접 조절
- Pressure→Spacing 없음

Tilt:
- Preset에서 Tilt를 켠 Brush에서만 Tip Angle에 적용

Barrel Rotation:
- v1 제외

### Texture
Texture Library 제공.
사용자 이미지 Import.
여러 Brush에서 재사용.
Brush별:
- Texture Scale
- Texture Angle

없음:
- Texture X/Y Offset
- 원본 Texture 이미지 편집기

### Asset 삭제
Library에서 Tip/Texture 삭제:
- Library 재사용 목록에서는 제거
- 기존 Brush는 깨지지 않음
- Brush 내부의 사용 자산은 유지
- Brush가 가진 자산을 Library에 다시 등록 가능

Brush 삭제:
- Library Asset은 유지

### Color Mixing
핵심 v1 기능.
Mode:
- 현재 Layer만 — 기본
- 보이는 Drawing Layer 색 참고

아래 Drawing Layer는 참조만 하고 수정하지 않는다.
별도 Smudge/Blend Tool 없음.

### ABR Import
v1 포함.
Photoshop 완전 호환은 보장하지 않음.
지원 가능한 속성을 자체 Brush Preset으로 변환.
실제 지원 범위는 기술 검증.

## Eraser

Brush Engine 기반 Sub Tool.
- 픽셀/부분 삭제
- 현재 선택 Drawing Layer에만 적용
- 다른 Layer 관통 삭제 없음
- 잠긴 Layer에는 적용 안 됨
- 크기 조절 UX는 Brush와 동일
- 사용자 Eraser/Preset/Pin/복제 지원

## Shape

지원:
- Line
- Rectangle
- Circle
- Ellipse
- Straight Arrow

Fill 없음.

생성:
- Drag로만 생성
- Drag 중 Preview
- 생성 직후 임시 활성 상태
- 활성 상태 Wheel = 선 굵기
- 이때 Canvas Zoom 차단
- 빈 Canvas 클릭 또는 다음 Shape 시작 시 확정
- 확정 후 일반 Drawing으로 변환
- 영구 Vector Shape 객체로 유지하지 않음

Shape 결과는 현재 선택 Drawing Layer에 들어감.
Shape마다 Layer 자동 생성하지 않음.

## Drawing Selection

이름을 `Drawing Selection`으로 구분한다.

Type:
- Rectangle
- Lasso

대상:
- 현재 선택된 Drawing Layer 집합
- 단일/다중 Layer 지원
- Canvas Item/Text Box는 대상 아님

선택 완료:
- Bounding Box
- Transform handles

지원:
- Move
- Scale
- Rotate
- Horizontal/Vertical Flip
- Delete

Transform:
- Preview
- Confirm / Cancel
- Confirm 전체 = 1 Drawing History
- Confirm 후 Selection 유지
- 영역 밖 클릭 = Deselect

선택 영역 → 새 Layer:
- 단일 Layer = 원본에서 분리
- 다중 Layer = 원 Layer별 분리 + 새 일반 Group + 상대 Z-order 유지

## Clipboard

Ctrl+C / Ctrl+X / Ctrl+V.

Paste:
- Mouse-following translucent Preview
- 좌클릭 배치
- Preview 유지 → 연속 배치
- 우클릭 → Paste Mode 종료
- 한 Paste Session 전체 = 1 Drawing History
- 다중 Layer 구조 유지 + 새 Group

별도 Drawing Duplicate 명령 없음.

## Layer

지원:
- Create / Delete / Rename
- 실제 Drawing Thumbnail
- Visibility
- Lock
- Opacity
- Alpha Lock / Lock Transparent Pixels
- Drag reorder
- Group
- Merge
- Blend Mode
- Clip to Layer Below
- Solo
- Color Label
- Search
- Filter
- Duplicate

Layer Pin 없음.

Layer 없음 + 첫 Drawing 입력:
- `Layer 1` 자동 생성/선택

+ Layer:
- 선택 Layer 바로 위
- 같은 hierarchy
- Group 내부면 같은 Group 내부
- Group 자체 선택 시 Group 내부 최상단
- Anchored Group이면 Anchor 상속
- 새 Layer 선택

+ Group:
- 선택 Layer 바로 위에 빈 일반 Group
- 선택 Layer를 Group으로 묶는 기능은 별도

다중 선택:
- Ctrl+Click 개별 Toggle
- Shift+Click Range
- 다중 Drag = Bundle 이동, 상대 순서 유지

Rename:
- 더블클릭 Inline
- Context Menu Rename

Delete:
- 확인창 없음
- Undo 복원

Solo:
- 단일/다중 Layer/Group 지원
- 기존 Visibility 상태 보존/복원

Filter:
- All
- Canvas Drawing
- Anchored Drawing
- Hidden
- Locked
- Color Label

Duplicate:
- Layer Duplicate v1 포함
- Group Duplicate v1 포함
- 복제본은 이후 원본과 독립
- Anchored Layer/Group 복제 시 같은 Anchor Target 유지

Group Merge:
- Drawing Layer만 Merge 대상

## Anchored Drawing

Anchor = Drawing Layer가 특정 Canvas Item의 **이동만** 따라가는 관계.

대상:
- Card
- Markdown/File Card
- Image
- Group
- 기타 지원 가능한 Canvas Item

Anchor가 의미하지 않는 것:
- 영역 제한 아님
- Clip/Mask 아님
- Target 내부로 강제 이동 아님
- Resize/Scale 연동 아님
- Drawing 형태 변경 아님

Anchor 순간:
- Drawing 현재 시각 위치 유지

이후:
- Target 이동 → 동일 이동량만큼 Drawing 이동
- Target Resize/Scale → Drawing 변화 없음
- Target 내용 변경 → Drawing 변화 없음

지원:
- 기존 Layer Anchor
- 새 Layer Anchor
- Target 변경
- Unanchor
- 다중 Layer Anchor
- Group Anchor

숨김 Layer도 Target 이동 추적.

### Anchor UI

Canvas Target 좌상단 작은 ⚓
- 낮은 대비
- Hover/선택 시 선명
- Anchored Layer 없으면 미표시
- Count 표시 없음

Canvas ⚓ 클릭:
- Layer Panel 관련 Anchored Group 이동/펼침

Layer Panel Target 이름 클릭:
- Canvas Target 이동/선택

Anchor 설정:
1. Layer/Group Drag & Drop → Canvas Item
2. Context Menu → Anchor to Canvas Object

Drop:
- Hover Target 강조
- ⚓ Bind 피드백
- 확인창 없이 즉시
- Ctrl+Z 가능

### Anchor 생명주기

Target 삭제:
- Anchored Drawing 삭제 금지
- Anchor 해제
- 현재 위치 유지 Canvas Drawing으로 전환

Target 삭제 Undo:
- Target + 원래 Anchor 관계 복원

개별 Target 복제:
- Anchored Drawing 복제 안 함

Canvas 전체 복제:
- Canvas Item + Drawing + Layer/Group 독립 복제
- 복제본끼리 Anchor 관계 유지

Target 다른 Canvas 이동:
- Anchor 해제
- Drawing은 원래 Canvas 현재 위치에 보존

Target 일시 미확인:
- Anchor 정보 보존
- 재연결 시도
- 별도 경고 UI 없음

### Group

일반 Group:
- 정리용
- 서로 다른 Anchor / Canvas Drawing 혼합 가능
- 넣고 빼는 것만으로 Anchor 변경 없음

Anchored Group:
- Group 전체가 하나의 Target
- 내부 Layer 같은 Target
- 새 Layer Anchor 상속

Ungroup:
- Drawing 보존
- Canvas Drawing으로 전환

일반 Group 전체 Anchor:
- 가능
- 내부 기존 Anchor가 덮어써지면 경고 후 변경/취소

### Merge

같은 Target:
- Merge 후 Anchor 유지

서로 다른 Anchor/Canvas Layer:
- Merge 허용
- 결과 Anchor를 사용자 선택
- Canvas 또는 관련 Target 후보

Undo:
- Merge 전 Layer 구조 + Drawing + Anchor 전체 복원

## Text

Text는 Drawing Layer가 아니다.
Text Layer도 만들지 않는다.

Text = Canvas 내부 독립 Item.

지원:
- Click → 기본 Text Box 생성
- Drag → 폭 지정 생성
- 생성 즉시 Markdown 편집
- 단일 클릭 선택
- Drag 이동
- 더블클릭 편집
- 바깥 클릭 → 편집 종료/렌더링
- Width 사용자 제어
- Height 내용에 따라 자동 확장
- Resize는 Width 중심, 재flow 후 Height 재계산

Style:
- Text Color
- Text Size
- Background ON/OFF + Color/Opacity
- Border ON/OFF + Color/Width/Opacity
- Corner Radius
- Padding

기본:
- 투명 Background
- Border OFF

Markdown:
- Obsidian 링크/코드 등 Theme 고유 스타일 유지
- 기본 Text Color는 일반 텍스트/Heading/Bold 등 Base 색에 적용

Text Preset/Sub Tool:
- Style 저장
- Markdown 내용은 저장하지 않음

Text 입력:
- Brush/Eraser/Shape/Drawing Selection 중 Text Box는 Drawing 입력을 가로채지 않음
- Text Tool에서 생성/편집
- Selection Mode에서 Canvas Item처럼 선택/이동/Resize

Text는:
- Layer Panel 미표시
- Anchor 없음
- Drawing Visibility 대상 아님
- Drawing Selection 대상 아님
- Drawing History 아님
- Canvas History 사용

향후 Canvas Item Group 기능과 연동 가능하나 v1 별도 추가하지 않음.

## Color Popup

Color는 독립 Tool이 아니다.

사용자 지정 Shortcut:
- Popup ON/OFF

Popup:
- 현재 Tool 유지
- Brush → Drawing Color
- Shape → Shape Color
- Text → Text Color

기본:
- 색 선택 시 자동 닫힘

Popup 상단 Pin:
- Pin ON이면 색 선택 후 유지
- 여러 색 연속 선택 가능

Eyedropper:
- Popup 안에서 사용 가능
- Canvas에서 실제 보이는 색 샘플링
- Drawing/Image/Card 등 포함
- 기본 Popup 상태에서는 샘플 후 닫힘
- Pin 상태에서는 샘플 후 유지

Eyedropper는 별도/임시 Tool 호출도 지원.

## Drawing Workspace

핵심 의미:
**Drawing 작업환경을 전환하는 단위.**

예:
- 웹툰 Workspace
- 스케치 Workspace

Workspace 전환:
- 현재 Workspace 작업환경 자동 저장
- 선택한 Workspace 환경으로 전환
- Canvas 작품 상태는 그대로 유지

Toolbar 맨 아래:
- 현재 Workspace 표시
- 빠른 전환

Settings:
- 생성
- Rename
- Duplicate
- Delete
- Export
- Import

Workspace 포함:
- Brush/Sub Tool/Preset
- 기본/수정/복제/Custom/ABR Brush
- 필요한 Tip/Texture Assets
- Eraser/Shape/Text Preset
- Tool Group/순서
- Tool 표시/숨김
- Pin
- Shortcut
- Tool 설정
- Drawing/Shape/Text Color
- Global Pen Pressure
- Toolbar/Context/Layer Panel 접힘/폭
- 마지막 Tool/Sub Tool

Workspace 미포함:
- Canvas Pan/Zoom
- 현재 Layer
- Layer 구조
- Anchor
- Drawing Visibility
- Drawing 실제 작품 데이터
- Selection/Drawing Mode 자체

Import:
- Import 후 자동 활성화 안 함
- 목록에 추가
- 사용자가 직접 전환
- 같은 이름이면 별도 Workspace 생성
- 일부 손상 Asset이 있어도 정상 항목은 Import
- 손상 항목은 제외 + 결과 표시
- 동일 Asset을 안전하게 판정 가능하면 재사용

Vault 간 자동 공유 없음.
Export/Import로 이동.

Workspace 변경 중 미확정 정상 편집:
- 안전하게 확정 후 전환

## Plugin Settings

Workspace와 분리.

Plugin 공통:
- Pen/Tablet 장치 설정
- Brush Cursor 표시 방식
- 기타 장치/프로그램 공통 환경

전체 Backup/Restore:
- 모든 Workspace
- Brush/Asset
- Plugin Settings

포함하지 않음:
- Canvas 작품 Drawing Data

Plugin 자체 작품 Backup 시스템은 만들지 않는다.

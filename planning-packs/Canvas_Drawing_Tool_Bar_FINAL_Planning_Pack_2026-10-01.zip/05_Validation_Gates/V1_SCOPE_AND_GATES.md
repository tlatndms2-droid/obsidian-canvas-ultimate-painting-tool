# v1 Scope / Development Gates

## v1 포함

- Drawing / Selection Mode
- Brush Engine
- Color Mixing
- Eraser
- Shape
- Text Canvas Item
- Drawing Selection / Transform
- Clipboard
- Layer / Group / Merge
- Layer Duplicate / Group Duplicate
- Alpha Lock
- Clip to Layer Below
- Blend Mode
- Solo
- Search / Filter / Color Label
- Anchored Drawing
- Drawing Workspace
- ABR Import
- Custom Tip / Texture Library
- Pen Pressure / Tilt / Pen Button
- Color Popup
- 자동 저장 / 복구
- 실제 Windows Vault 설치/업데이트
- 사용자 문서
- Gate별 Sandbox 검증
- Gate별 GitHub Release

## v1 제외 / 후속

- Layer Mask
- Reference Layer
- Fill Tool
- Gradient Tool
- Symmetry / Ruler
- Dual Brush / Layered Brush Tips
- Barrel Rotation
- 별도 Smudge/Blend Tool
- Post-correction
- 별도 Taper 설정
- Color Dynamics
- Plugin 자체 작품 Backup
- Community Plugins 공개 등록

## Gate 순서

1. Canvas/저장 기반
2. Drawing Engine
3. Brush/Pen Input
4. Layer System
5. Drawing Selection/Transform
6. Anchored Drawing
7. Shape/Text
8. Workspace/Asset
9. 통합
10. Performance/Data Safety
11. v1 Final

## Gate 통과 절차

`구현 → Codex 자체 검증 → Obsidian Sandbox 검증 → Sandbox 열린 상태 유지 → 사용자 직접 확인 → Pass → 증거 보존 → GitHub Release → 다음 Gate`

실패:
- 동일 Gate로 돌아감
- 수정
- 재검증
- 사용자 재확인
- 통과 전 다음 Gate 금지

## Version / Release

초기 Gate Release:
`0.1.0 → 0.1.1 → 0.1.2 → ...`

한번 발행한 Release 파일은 덮어쓰지 않는다.
과거 Gate 기능 수정도 새 Patch Release.

모든 v1 Gate + 통합 검증 통과:
`1.0.0`

## Release Notes 고정 형식

- Version
- Gate
- 구현 범위
- 주요 변경사항
- Sandbox 검증 결과
- 사용자 직접 확인 결과
- 알려진 제한사항
- 다음 Gate

## 검증 증거 보존

버전별:
- Screenshot
- Pass/Fail 기록
- 성능 측정값
- 데이터 안전 테스트 결과
- 재현 절차
- 사용자 직접 확인 결과
- 필요 시 Log

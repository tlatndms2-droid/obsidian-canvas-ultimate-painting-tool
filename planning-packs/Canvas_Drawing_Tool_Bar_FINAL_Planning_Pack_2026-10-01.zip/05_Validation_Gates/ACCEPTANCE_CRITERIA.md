# Acceptance Criteria

## 공통 완료 기준

각 v1 기능은 아래를 만족해야 한다.

1. 요구된 사용자 동작 재현
2. 기존 Obsidian Canvas 조작 비파괴
3. 저장 후 재열기/재실행 시 상태 유지
4. Undo/Redo 규칙 일치
5. 데이터 손실 없음
6. 해당 기능의 성능 요구 만족
7. Sandbox에서 실제 검증
8. 검증 상태를 사용자에게 그대로 노출
9. 사용자 직접 확인
10. 증거 보존
11. Gate GitHub Release 완료

## Brush / Pen

- Pressure Size/Opacity가 독립 동작
- Global Pressure → Preset Dynamics 순서 체감 확인
- Mouse=100% Pressure
- Tilt ON Brush에서만 Tip Angle 변화
- Stabilization Preset별 유지
- Ctrl+Alt+Drag Size 조절
- Cursor 실제 크기/형태와 일치
- Brush/Pen 입력이 Pan/Zoom/Card 조작과 충돌하지 않음

## Color Mixing

- 현재 Layer만 모드
- 보이는 Drawing Layer 참고 모드
- 참조 Layer 원본 비변경
- Toggle Shortcut
- Preset별 상태 저장
- 장시간 Painting에서도 P0 성능 유지

## Eraser

- 현재 Layer만 지움
- 잠긴 Layer 보호
- 다른 Layer 관통 삭제 없음
- Brush형 Size/Pressure UX 유지

## Shape

- Drag Preview
- 생성 직후 임시 활성
- Wheel 굵기
- 확정 후 일반 Drawing
- 현재 선택 Drawing Layer에 저장
- 이후 Drawing Selection으로 편집

## Text

- Canvas Item으로 생성
- Markdown 편집
- Width Resize + Height Auto
- Canvas Selection으로 이동/Resize
- Drawing Layer/Panel/Anchor와 분리
- Drawing Tool 사용 중 Text가 입력을 가로채지 않음
- Canvas History Undo/Redo

## Drawing Selection

- Rectangle/Lasso
- 단일/다중 Layer
- Move/Scale/Rotate/Flip/Delete
- Preview + Confirm/Cancel
- Confirm = 1 History
- 새 Layer 분리
- 다중 Layer 구조 보존

## Clipboard

- Copy/Cut/Paste
- Paste Preview
- 연속 배치
- 우클릭 종료
- Session 전체 1 History
- 다중 Layer 구조 보존

## Layer / Group

- Create/Delete/Rename
- Thumbnail
- Visibility/Lock/Opacity
- Alpha Lock
- Clip Below
- Blend Mode
- Solo
- Search/Filter
- Color Label
- Duplicate
- Group Duplicate
- Multi-select
- Drag reorder
- Undo 복원

## Anchor

- 이동만 추적
- Resize/Scale 미추적
- Target 삭제 시 Drawing 보존
- 삭제 Undo 시 관계 복원
- Target 변경/Unanchor
- 다중 Layer/Group
- Canvas 전체 복제 시 복제본끼리 관계 유지
- 개별 Target 복제 시 Drawing 미복제
- 다른 Canvas 이동 시 Anchor 해제

## Workspace

- Toolbar 하단에서 즉시 전환
- 전환 후 Brush/Tool/Preset/UI 환경 변경
- 이전 Workspace로 돌아오면 마지막 작업환경 복원
- Canvas 작품 상태 변화 없음
- Import 후 자동 활성화 안 함
- Export/Import로 Custom Brush/Asset 복원
- Tool 순서/숨김 상태 Workspace별 복원

## Color Popup

- Shortcut Open/Close
- 현재 Tool 유지
- 색 선택 후 기본 자동 닫힘
- Pin 시 유지
- Eyedropper 동작
- 현재 Tool Color Slot 반영

## Data Safety

다음 전체 통과:
- 자동 저장
- Canvas 닫기/재열기
- Obsidian 재시작
- Rename/Move
- Canvas 복제
- Plugin Disable/Enable
- Reinstall
- Obsidian `.trash` 복원
- Windows 휴지통 복원
- 저장 실패 복구
- 손상 데이터 원본 보호
- 구버전/신버전 불일치 보호

Critical 데이터 손실 재현 시 v1 완료 불가.

## Performance

실제 작업 시나리오:
- 많은 Stroke
- 많은 Layer/Group
- Anchored Drawing
- Brush/Color Mixing
- Pan/Zoom
- Card 이동
- Selection/Transform
- Auto-save
- 장시간 사용

Plugin OFF 대비 기존 Canvas 조작에 명확한 체감 저하가 없어야 함.

측정:
- FPS
- Frame Time
- Input Latency
- Memory

수치만으로 판정하지 않고 실제 작업 시나리오 + 사용자 체감 + 측정값을 함께 사용.

# Technical Validation — Codex Responsibility

아래는 사용자에게 다시 묻지 않는다.
Codex가 실제 Obsidian 환경에서 검증하고 Gate 증거로 남긴다.

## Obsidian / Canvas
- 검증 대상 Obsidian Desktop 버전
- Canvas 내부 연동 가능 범위
- Canvas Item 안정 식별
- Rename/Move/Copy 시 연결 유지
- 여러 Canvas/Window 상태 격리

## Rendering / Performance
- Rendering Engine
- GPU/CPU 분배
- Cache
- Worker
- Spatial Index
- Culling
- LOD
- Thumbnail Lazy Update
- Pan/Zoom 전체 재생성 방지
- 숨김 Layer Rendering Skip

## Drawing Engine
- Pressure 보간
- Tilt
- Cursor 형태
- Stabilization
- Tip/Texture
- Spray/Scatter
- Dynamics
- Color Mixing 품질/성능

## ABR
- 실제 지원 가능한 속성 목록
- 지원 불가 속성
- Import 실패/부분 Import 처리
- 66 Brush 시험 결과를 전체 호환으로 확대 해석하지 않음

## Blend Mode
- 안정 재현 가능한 모드
- 성능 비용
- CSP 주요 모드 중 v1 지원 목록

## Pen / Tablet
- Wacom 등 실제 Pen Pressure
- Tilt
- Back Eraser
- Side Button
- 기기별 이벤트 구분

## Text
- Canvas Item으로 구현 가능한 범위
- Markdown Editor/Renderer 재사용 가능성
- Obsidian Shortcut 충돌
- Width/Height Auto Layout

## History
- Drawing History / Canvas History의 사용자 결과 일치
- 현재 작업 대상 기준 Ctrl+Z
- 복합 작업 Atomic Undo

## Storage / Recovery
- Drawing Data 포맷
- File Path
- ID
- Serialization
- Versioning
- Last-known-good
- Crash/partial save
- Corruption detect
- Migration / downgrade protection
- 휴지통 Restore / permanent delete cleanup

## Community Plugin Compatibility
실사용 Vault에서 Canvas/Input/UI/Shortcut에 영향을 주는 주요 Plugin과 충돌 검사.
모든 Plugin 호환 보장은 아님.

## 반드시 남길 증거
- Test procedure
- Actual result
- Pass/Fail
- Screenshot/Video 필요 시
- Metrics
- Logs 필요 시
- Known limitations

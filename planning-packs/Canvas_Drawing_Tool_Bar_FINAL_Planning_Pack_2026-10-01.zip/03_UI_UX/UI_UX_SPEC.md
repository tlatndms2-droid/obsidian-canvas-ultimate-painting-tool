# UI / UX Spec

## Desktop Layout

`좌측 Drawing Toolbar → Toolbar 오른쪽 Tool Context Panel → 중앙 Obsidian Canvas → 우측 Layer Panel`

별도 Drawing 화면 없음.

## Drawing Toolbar

상단:
- Selection / Drawing Mode

중간:
- Drawing Tool 영역
- Tool 순서 변경 가능
- Tool 표시/숨김 가능
- Workspace별 저장

하단:
- Drawing Workspace Selector 고정

구분선 사용자 추가 기능 없음.

## Tool Context Panel

- Tool마다 같은 위치에서 내용 교체
- 접기/펼치기
- 폭 조절
- 상태 Workspace 저장
- Pinned 영역은 현재 Tool Panel 상단

## Layer Panel

오른쪽.

상단:
- Canvas Drawing
- Anchored Drawing
- All Drawing
글로벌 임시 Visibility Override

이 Override는 개별 Layer Visibility 값을 덮어쓰지 않는다.
다시 켜면 원래 상태 복원.

Layer 목록:
- Thumbnail
- Visibility
- Name
- Lock
- Anchor Target 표시
- Color Label
- Selection Highlight

검색/필터 제공.

## Text Box UI

Canvas Item으로 취급.
Layer Panel에 표시하지 않음.
Drawing Toolbar의 Text Tool에서 생성/편집.
Selection Mode에서는 기존 Canvas Item처럼 조작.

## Color Popup

항상 보이는 Color Wheel 아님.
Shortcut으로 Popup.
기본 색 선택 후 자동 닫힘.
상단 Pin으로 고정.
Pin 시 계속 열림.
Eyedropper 포함 가능.
현재 Tool 유지.

## 상태 피드백

저장:
- 정상 상태 표시 없음
- 반복 저장 실패로 실제 위험이 있을 때만 작은 `Drawing 저장 실패`
- 성공 시 자동 제거

Anchor:
- Target 좌상단 ⚓
- Hover/선택 시 강조

## 명칭

- Selection = Canvas Item 조작
- Drawing Selection = Drawing 영역 선택

두 Selection 명칭을 UI에서 구분한다.
